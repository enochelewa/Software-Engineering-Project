//
// Created by enoch on 04/05/2021.
//
#include "Board.h"
#ifndef SE_ASSIGNMENT2_MOVES_H
#define SE_ASSIGNMENT2_MOVES_H

#endif //SE_ASSIGNMENT2_MOVES_H

int updateBoard(char[], struct Board *Sboard, int, int); // function to update the board by flipping
int moveDetection(struct Board *b, int t);// Function to check whether the board has available moves for the players